# Static folder

## Description
This contains all the static files/folders

## The http.Fileserver handler
Go’s net/http package ships with a built-in http.FileServer handler which you can use to
serve files over HTTP from a specific directory.